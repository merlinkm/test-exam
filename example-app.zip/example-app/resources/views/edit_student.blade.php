@extends('template')
@section('content')

<div class="container">
  <h3>Edit Students</h3>

  @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

@if(isset($success))
<div class="alert alert-success">
        <ul>
                <li>{{ $success }}</li>
        </ul>
    </div>

@endif

   <form action="/edit-student/{{$student->id}}" method="post">
   	@csrf
    <div class="row">
      <div class="col">
        <input type="text" class="form-control"  placeholder="Enter Name" name="name" value="{{$student->name}}">
      </div>
      <div class="col">
        <input type="text" class="form-control" placeholder="Enter Age" name="age" value="{{$student->age}}">
      </div>

      <div class="col">
      	<select name="gender" class="form-control">
      		<option value="">Select Gender</option>
      		<option value="M" <?= $student->gender=='M'?'selected':'' ?> >Male</option>
      		<option value="F" <?= $student->gender=='F'?'selected':'' ?>>Female</option>
      	</select>
      </div>

      <div class="col">
        <select name="teacher" class="form-control">
      		<option value="">Select Teacher</option>
      		<option value="Kaite" <?= $student->teacher=='Kaite'?'selected':'' ?>>Kaite</option>
      		<option value="Max" <?= $student->teacher=='Max'?'selected':'' ?>>Max</option>
      	</select>

      
    </div>
    <button type="submit" name="submit" class="btn btn-primary mt-3">Submit</button>
  </form>

</div>
@endsection