@extends('template')
@section('content')

<div class="container">
  <h3>Students Table</h3>
  <table class="table">
     <tr>
    <th>ID</th>
    <th>Name</th>
    <th>Age</th>
    <th>Gender</th>
    <th>Reporting Teacher</th>
    <th>Action</th>
  </tr>
  <?php if(isset($students)){
  foreach($students as $row){
?>
  <tr>
    <td>{{$row->id}}</td>
    <td>{{$row->name}}</td>
    <td>{{$row->age}}</td>
    <td>{{$row->gender}}</td>
    <td>{{$row->teacher}}</td>
    <td><a href="edit-student/{{$row->id}}">Edit</a> / <a href="delete-student/{{$row->id}}">Delete</a> </td>
  </tr>
  <?php }
} ?>
  </table>
  
</div>
@endsection


