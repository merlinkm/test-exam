@extends('template')
@section('content')

<div class="container">
  <h3>View Students Marks</h3>
  <table class="table">
     <tr>
    <th>ID</th>
    <th>Name</th>
    <th>Maths</th>
    <th>Science</th>
    <th>History</th>
    <th>Term</th>
    <th>Total Marks</th>
    <th>Created On</th>
    <th>Action</th>
  </tr>
  <?php if(isset($mark)){
  foreach($mark as $row){
?>
  <tr>
    <td>{{$row->id}}</td>
    <td>{{$row->name}}</td>
    <td>{{$row->maths}}</td>
    <td>{{$row->science}}</td>
    <td>{{$row->history}}</td>
    <td>{{$row->term}}</td>
    <td><?= $row->maths + $row->science + $row->history; ?></td>
    <td> <?= date('M d, Y h:i a',strtotime($row->created_at)) ?></td>
    <td><a href="#">Edit</a> / <a href="#">Delete</a> </td>
  </tr>
  <?php }
} ?>
  </table>
  
</div>
@endsection


