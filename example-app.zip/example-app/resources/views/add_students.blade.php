@extends('template')
@section('content')

<div class="container">
  <h3>Add Students</h3>

  @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

@if(isset($success))
<div class="alert alert-success">
        <ul>
                <li>{{ $success }}</li>
        </ul>
    </div>

@endif

   <form action="/add-students" method="post">
   	@csrf
    <div class="row">
      <div class="col">
        <input type="text" class="form-control"  placeholder="Enter Name" name="name">
      </div>
      <div class="col">
        <input type="text" class="form-control" placeholder="Enter Age" name="age">
      </div>

      <div class="col">
      	<select name="gender" class="form-control">
      		<option value="">Select Gender</option>
      		<option value="M">Male</option>
      		<option value="F">Female</option>
      	</select>
      </div>

      <div class="col">
        <select name="teacher" class="form-control">
      		<option value="">Select Teacher</option>
      		<option value="Kaite">Kaite</option>
      		<option value="Max">Max</option>
      	</select>

      
    </div>
    <button type="submit" name="submit" class="btn btn-primary mt-3">Submit</button>
  </form>

</div>
@endsection