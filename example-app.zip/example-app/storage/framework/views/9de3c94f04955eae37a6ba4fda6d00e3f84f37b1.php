
<?php $__env->startSection('content'); ?>

<div class="container">
  <h3>View Students Marks</h3>
  <table class="table">
     <tr>
    <th>ID</th>
    <th>Name</th>
    <th>Maths</th>
    <th>Science</th>
    <th>History</th>
    <th>Term</th>
    <th>Total Marks</th>
    <th>Created On</th>
    <th>Action</th>
  </tr>
  <?php if(isset($mark)){
  foreach($mark as $row){
?>
  <tr>
    <td><?php echo e($row->id); ?></td>
    <td><?php echo e($row->name); ?></td>
    <td><?php echo e($row->maths); ?></td>
    <td><?php echo e($row->science); ?></td>
    <td><?php echo e($row->history); ?></td>
    <td><?php echo e($row->term); ?></td>
    <td><?= $row->maths + $row->science + $row->history; ?></td>
    <td> <?= date('M d, Y h:i a',strtotime($row->created_at)) ?></td>
    <td><a href="#">Edit</a> / <a href="#">Delete</a> </td>
  </tr>
  <?php }
} ?>
  </table>
  
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\example-app\resources\views/view-marks.blade.php ENDPATH**/ ?>