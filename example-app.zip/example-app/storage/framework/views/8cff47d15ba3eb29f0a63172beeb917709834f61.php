
<?php $__env->startSection('content'); ?>

<div class="container">
  <h3>Add Students</h3>

  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php if(isset($success)): ?>
<div class="alert alert-success">
        <ul>
                <li><?php echo e($success); ?></li>
        </ul>
    </div>

<?php endif; ?>

   <form action="/add-students" method="post">
   	<?php echo csrf_field(); ?>
    <div class="row">
      <div class="col">
        <input type="text" class="form-control"  placeholder="Enter Name" name="name">
      </div>
      <div class="col">
        <input type="text" class="form-control" placeholder="Enter Age" name="age">
      </div>

      <div class="col">
      	<select name="gender" class="form-control">
      		<option value="">Select Gender</option>
      		<option value="M">Male</option>
      		<option value="F">Female</option>
      	</select>
      </div>

      <div class="col">
        <select name="teacher" class="form-control">
      		<option value="">Select Teacher</option>
      		<option value="Kaite">Kaite</option>
      		<option value="Max">Max</option>
      	</select>

      
    </div>
    <button type="submit" name="submit" class="btn btn-primary mt-3">Submit</button>
  </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\example-app\resources\views/add_students.blade.php ENDPATH**/ ?>