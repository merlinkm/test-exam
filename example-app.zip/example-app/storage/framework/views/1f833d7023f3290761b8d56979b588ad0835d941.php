
<?php $__env->startSection('content'); ?>

<div class="container">
  <h3>Edit Students</h3>

  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php if(isset($success)): ?>
<div class="alert alert-success">
        <ul>
                <li><?php echo e($success); ?></li>
        </ul>
    </div>

<?php endif; ?>

   <form action="/edit-student/<?php echo e($student->id); ?>" method="post">
   	<?php echo csrf_field(); ?>
    <div class="row">
      <div class="col">
        <input type="text" class="form-control"  placeholder="Enter Name" name="name" value="<?php echo e($student->name); ?>">
      </div>
      <div class="col">
        <input type="text" class="form-control" placeholder="Enter Age" name="age" value="<?php echo e($student->age); ?>">
      </div>

      <div class="col">
      	<select name="gender" class="form-control">
      		<option value="">Select Gender</option>
      		<option value="M" <?= $student->gender=='M'?'selected':'' ?> >Male</option>
      		<option value="F" <?= $student->gender=='F'?'selected':'' ?>>Female</option>
      	</select>
      </div>

      <div class="col">
        <select name="teacher" class="form-control">
      		<option value="">Select Teacher</option>
      		<option value="Kaite" <?= $student->teacher=='Kaite'?'selected':'' ?>>Kaite</option>
      		<option value="Max" <?= $student->teacher=='Max'?'selected':'' ?>>Max</option>
      	</select>

      
    </div>
    <button type="submit" name="submit" class="btn btn-primary mt-3">Submit</button>
  </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\example-app\resources\views/edit_student.blade.php ENDPATH**/ ?>