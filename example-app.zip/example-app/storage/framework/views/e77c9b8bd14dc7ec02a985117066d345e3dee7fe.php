
<?php $__env->startSection('content'); ?>

<div class="container">
  <h3>Add Marks</h3>

  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php if(isset($success)): ?>
<div class="alert alert-success">
        <ul>
                <li><?php echo e($success); ?></li>
        </ul>
    </div>

<?php endif; ?>

   <form action="/add-marks" method="post">
   	<?php echo csrf_field(); ?>
    <div class="row">
      <div class="col">
        <select name="student" class="form-control">
          <option value="">Select Student</option>
          <?php if(isset($student)){
            foreach ($student as $key => $value) {
              ?>
              <option value='<?php echo e($value->id); ?>' ><?php echo e($value->name); ?></option>
              <?php
            }
          } ?>
          
        </select>
      </div>
      

      <div class="col">
      	<select name="term" class="form-control">
      		<option value="">Select Term</option>
      		<option value="One">One</option>
      		<option value="Two">Two</option>
      	</select>
      </div>

      <div class="col">
        <input type="number" class="form-control" placeholder="Enter Maths Mark" name="maths">
      </div>

      <div class="col">
        <input type="number" class="form-control" placeholder="Enter Science Mark" name="science">
      </div>

      <div class="col">
        <input type="number" class="form-control" placeholder="Enter History Mark" name="history">
      </div>

      
    <button type="submit" name="submit" class="btn btn-primary mt-3">Submit</button>
  </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\example-app\resources\views/add-marks.blade.php ENDPATH**/ ?>