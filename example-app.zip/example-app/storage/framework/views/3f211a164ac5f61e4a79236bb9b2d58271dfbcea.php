<?php $__env->startSection('content'); ?>

<div class="container">
  <h3>Students Table</h3>
  <table class="table">
     <tr>
    <th>ID</th>
    <th>Name</th>
    <th>Age</th>
    <th>Gender</th>
    <th>Reporting Teacher</th>
    <th>Action</th>
  </tr>
  <?php if(isset($students)){
  foreach($students as $row){
?>
  <tr>
    <td><?php echo e($row->id); ?></td>
    <td><?php echo e($row->name); ?></td>
    <td><?php echo e($row->age); ?></td>
    <td><?php echo e($row->gender); ?></td>
    <td><?php echo e($row->teacher); ?></td>
    <td><a href="edit-student/<?php echo e($row->id); ?>">Edit</a> / <a href="delete-student/<?php echo e($row->id); ?>">Delete</a> </td>
  </tr>
  <?php }
} ?>
  </table>
  
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\example-app\resources\views/welcome.blade.php ENDPATH**/ ?>