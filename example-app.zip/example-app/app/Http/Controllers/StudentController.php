<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Student;
use App\Marks;
use DB;

class StudentController extends Controller
{
	public function index()
	{
		$students = Student::all();
		return view('welcome',compact('students'));
	}

	public function create(){
		return view('add_students');
	}

	public function store(Request $request)
	{
		$validatedData = $request->validate([
			'name' => 'required',
			'age' => 'required',
			'gender' => 'required',
			'teacher' => 'required',
		]);

		$student = new Student;

        $student->name = $request->name;
        $student->age = $request->age;
        $student->gender = $request->gender;
        $student->teacher = $request->teacher;

        $student->save();

        return back()->with('success','successfully add a student');
	}

	public function edit($id)
	{
		$student = Student::find($id);
		return view('edit_student',compact('student'));
	}

	public function update(Request $request,$id)
	{
		$validatedData = $request->validate([
			'name' => 'required',
			'age' => 'required',
			'gender' => 'required',
			'teacher' => 'required',
		]);

		$student = Student::find($id);

        $student->name = $request->name;
        $student->age = $request->age;
        $student->gender = $request->gender;
        $student->teacher = $request->teacher;

        $student->save();

        return redirect('/')->with('success','successfully update the student');
	}

	public function delete($id)
	{
		$deletedRows = Student::where('id',$id)->delete();

		return redirect('/')->with('success','successfully delete the student');
	}

	public function addMarks()
	{
		$student = Student::all();
		return view('add-marks',compact('student'));
	}

	public function createMarks(Request $request)
	{
		$validatedData = $request->validate([
			'student' => 'required',
			'term' => 'required',
			'maths' => 'required|integer',
			'science' => 'required|integer',
			'history' => 'required|integer',
		]);

		$mark = new Marks;

        $mark->student_id = $request->student;
        $mark->term = $request->term;
        $mark->maths = $request->maths;
        $mark->science = $request->science;
        $mark->history = $request->history;

        $mark->save();

        return back()->with('success','successfully add student marks');
	}

	public function viewMarks()
	{
		$mark = DB::table('marks')
		->join('students','students.id','=','marks.student_id')
		->select('marks.*','students.name')
		->get();

		return view('view-marks',compact('mark'));
	}
}
