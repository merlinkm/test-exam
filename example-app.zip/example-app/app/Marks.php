<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Marks extends Model
{
    protected $table = 'marks';

    protected $fillable = [
        'student_id', 'maths', 'science', 'history','term'
    ];
}
